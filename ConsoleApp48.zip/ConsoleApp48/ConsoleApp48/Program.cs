﻿using System;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace StockControl
{
    class Program
    {
        static void Main(string[] args)
        {
            // Employee(string name, int departmentId, DateTime dateOfBirth, string gender, double raise = 0)
            Department d1 = new Department("dev1", 25, 1000);
            Department d2 = new Department("dev2", 20, 10027);
            d1.AddEmployee(10);
            d1.AddEmployee(30);
            d2.AddEmployee(20);
            d1.AddProduct(99, 78);
            d1.AddProduct(429, 536);
            d2.AddProduct(429, 536);


            //Product(string productName, int departmentID, double sellingPrice, double buyingPrice)
            Product p1 = new Product("shebs", 212, 45.3, 40);
            Product p2 = new Product("tomato", 846, 50.7, 54);
            ObservableDictionary<int,Product> dProducts= new ObservableDictionary<int, Product>();


            dProducts.Add(12,p1);
            dProducts.Add(13,p2);

            DataTable tblProduct = new DataTable();
            tblProduct.Columns.Add("ID", typeof(int));
            tblProduct.Columns.Add("productName", typeof(string));
            tblProduct.Columns.Add("departmentID", typeof(int));
            tblProduct.Columns.Add("sellingPrice", typeof(double));
            tblProduct.Columns.Add("buyingPrice", typeof(double));





            foreach (var item in dProducts)
            {
                tblProduct.Rows.Add(item.Key, item.Value.Name, item.Value.DepartmentID, item.Value.SellingPrice, item.Value.BuyingPrice);

            }
            var products_path = @"CSV_FILE/products_data.csv";

            //public Order(int productID, Product orderedProduct, int orderedQuantity) + OrderDate
            //C.ToCSV(tblProduct, products_path);

            ObservableDictionary<int,Product> read_Product = new ObservableDictionary<int,Product>();

            //C.ReadCSV(read_Product, products_path);

            //foreach (var item in read_Product)
            //{
            //    Console.WriteLine(item.Value.Name);   
            //}



            






            //public Order(int productID, Product orderedProduct, int orderedQuantity) + OrderDate
            ObservableCollection<Order> li_Orders = new ObservableCollection<Order>();
            ObservableCollection<Order> Read_Orders = new ObservableCollection<Order>();

            Order o1 = new Order(342, p1, 3, DateTime.Now);
            Order o2 = new Order(767, p2, 4, new DateTime(2010,2,2));
            li_Orders.Add(o1);
            li_Orders.Add(o2);


            DataTable tblOrder = new DataTable();


            tblOrder.Columns.Add("productID", typeof(int));
            tblOrder.Columns.Add("orderedProduct", typeof(Product));
            tblOrder.Columns.Add("orderedQuantity", typeof(int));
            tblOrder.Columns.Add("orderDate", typeof(DateTime));

            foreach (var item in li_Orders)
            {
                tblOrder.Rows.Add(item.ProductID,item.OrderedProduct,item.OrderedQuantity,item.OrderDate);
            }
            var orders_path = @"CSV_FILE/orders_data.csv";

            //D.ToCSV(tblOrder, orders_path);
            D.ReadCSV(Read_Orders, orders_path);

            foreach (var item in Read_Orders)
            {
                Console.WriteLine($"{item.ProductID},{item.OrderedProduct.Name},{item.OrderDate}");
            }

            ObservableDictionary<int, Department> dparts = new ObservableDictionary<int, Department>();
            ObservableDictionary<int, Department> ReadedDepartments = new ObservableDictionary<int, Department>();
            dparts.Add(1, d1);
            dparts.Add(2, d2);
            ObservableDictionary<int, Employee> demployees = new ObservableDictionary<int, Employee>();

            ObservableDictionary<int, Employee> ReadedEmployee = new ObservableDictionary<int, Employee>();

            //WarehouseWorker(string name, int departmentId, string gender, DateTime dateOfBirth, int productsProcessed = 0)
            Employee e1 = new WarehousePacker("Mhmd", 12, "male", (new DateTime(1950, 12, 31)), 4);

            //WarehousePacker(string name, int departmentId, string gender, DateTime dateOfBirth, int productsPacked = 0)
            Employee e2 = new WarehouseWorker("Alaa", 15, "female", new DateTime(2000, 1, 3), 3);

            Employee e3 = new MaterialHandler("Samer", 15, "male", new DateTime(1998, 2, 3), 2);

            demployees.Add(211901186, e1);
            demployees.Add(204468115, e2);
            demployees.Add(301596648, e3);



            DataTable tblDepartment = new DataTable();
            //Department(string departmentName, int employeeCapacity, int productCapacity)
            tblDepartment.Columns.Add("departmentID", typeof(int));
            tblDepartment.Columns.Add("departmentName", typeof(string));
            tblDepartment.Columns.Add("employeeCapacity", typeof(int));
            tblDepartment.Columns.Add("productCapacity", typeof(int));
            tblDepartment.Columns.Add("productsID", typeof(Dictionary<int,int>));
            tblDepartment.Columns.Add("employeesID", typeof(SortedSet<int>));

            foreach (var item in dparts)
            {
                tblDepartment.Rows.Add(item.Key, item.Value.Name, item.Value.EmployeeCapacity
                                      , item.Value.ProductCapacity, item.Value.GetProducts(), item.Value.GetEmployeesID());
            }
            var department_path = @"CSV_FILE/departments_data.csv";

            //B.ToCSV(tblDepartment, department_path);
            //B.ReadCSV(ReadedDepartments, department_path);

            foreach (var item in ReadedDepartments)
            {
                Console.WriteLine($"id:{item.Key},departmentName:{item.Value.Name}");
                foreach (var pId in item.Value.GetProducts()) { Console.Write($"[{pId.Key},{pId.Value}],"); }
                Console.WriteLine();
                foreach (var eId in item.Value.GetEmployeesID()) { Console.Write($"[{eId}],"); }
                Console.WriteLine();
            }

            DataTable tblEmployee = new DataTable();
            //columns  
            tblEmployee.Columns.Add("ID", typeof(int));
            tblEmployee.Columns.Add("Name", typeof(string));
            tblEmployee.Columns.Add("departmentId", typeof(int));
            tblEmployee.Columns.Add("gender", typeof(string));
            tblEmployee.Columns.Add("dateOfBirth", typeof(DateTime));
            tblEmployee.Columns.Add("employeeType", typeof(Data.EmployeeTypes));
            tblEmployee.Columns.Add("special", typeof(int));


            foreach (var item in demployees)
            {
                if (item.Value is WarehousePacker wp)
                {
                    tblEmployee.Rows.Add(item.Key, wp.Name, wp.DepartmentID, wp.Gender, wp.DateOfBirth.Date, Data.EmployeeTypes.WarehousePacker, wp.ProductsPacked);
                }
                else if (item.Value is WarehouseWorker ww)
                {
                    tblEmployee.Rows.Add(item.Key, ww.Name, ww.DepartmentID, ww.Gender, ww.DateOfBirth.Date, Data.EmployeeTypes.WarehouseWorker, ww.ProductsProcessed);
                }
                else if (item.Value is MaterialHandler mh)
                {
                    tblEmployee.Rows.Add(item.Key, mh.Name, mh.DepartmentID, mh.Gender, mh.DateOfBirth, Data.EmployeeTypes.MaterialHandler, mh.MaterialHandled);
                }
                else
                {
                    throw new Exception();
                }
            }

            
            var employee_path = @"CSV_FILE/employees_data.csv";
            //A.ToCSV(tblEmployee, employee_path);
            A.ReadCSV(ReadedEmployee, employee_path);
            //A.Reset(tblEmployee, employee_path);

            //foreach (var item in ReadedEmployee)
            //{
            //    Console.WriteLine($"id : {item.Key}\t" +
            //        $"name : {item.Value.Name}"
            //        );}
            Console.WriteLine("DONE");
            Console.ReadLine();
        }
        public static void addRecord(string ID, string name, string Quantity, string Price, string PriceTax, string filepath)
        {
            try
            {
                using (System.IO.StreamWriter file = new System.IO.StreamWriter(filepath, true))
                {
                    file.WriteLine(ID + "," + name + "," + Quantity + "," + Price
                        );
                }
            }
            catch (Exception ex)
            {

                throw new ApplicationException("This program didd an oopsite :", ex);
            }
        }
        public static DataTable createDataTable()
        {
            DataTable table = new DataTable();
            //columns  
            table.Columns.Add("ID", typeof(int));
            table.Columns.Add("NAME", typeof(string));
            table.Columns.Add("CITY", typeof(string));

            //data  
            table.Rows.Add(111, "Devesh", "Ghaziabad");
            table.Rows.Add(222, "ROLI", "KANPUR");
            table.Rows.Add(102, "ROLI", "MAINPURI");
            table.Rows.Add(212, "DEVESH", "KANPUR");
            table.Rows.Add(102, "NIKHIL", "GZB");
            table.Rows.Add(212, "HIMANSHU", "NOIDa");
            table.Rows.Add(102, "AVINASH", "NOIDa");
            table.Rows.Add(212, "BHUPPI", "GZB");

            return table;
        }
    }

    public static class A
    {
        public static void Reset(DataTable dtDataTable, string strFilePath)
        {
            dtDataTable = new DataTable();
            ToCSV(dtDataTable, strFilePath);
            //File.Delete(strFilePath);
        }
        public static void ReadCSV(ObservableDictionary<int, Employee> employees, string filename)
        {
            var st = new StreamReader(filename);
            var line1 = st.ReadLine();//Skip Line
            while (!st.EndOfStream)
            {
                var line = st.ReadLine();
                var values = line.Split(',');
                if ((Data.EmployeeTypes)Convert.ToInt32(values[5]) ==Data.EmployeeTypes.WarehousePacker )
                {
                    var wp = new WarehousePacker(values[1], Convert.ToInt32(values[2]), values[3], Convert.ToDateTime(values[4]), Convert.ToInt32(values[6]));
                    employees.Add(Convert.ToInt32(values[0]), wp);
                }
                else if ((Data.EmployeeTypes)Convert.ToInt32(values[5]) == Data.EmployeeTypes.WarehouseWorker)
                {
                    var ww = new WarehouseWorker(values[1], Convert.ToInt32(values[2]), values[3], Convert.ToDateTime(values[4]), Convert.ToInt32(values[6]));
                    employees.Add(Convert.ToInt32(values[0]), ww);
                }
                else if ((Data.EmployeeTypes)Convert.ToInt32(values[5]) == Data.EmployeeTypes.MaterialHandler)
                {
                    var mh = new MaterialHandler(values[1], Convert.ToInt32(values[2]), values[3], Convert.ToDateTime(values[4]), Convert.ToInt32(values[6]));
                    employees.Add(Convert.ToInt32(values[0]), mh);
                }
                else
                {
                    throw new Exception();
                }
            }
        }
        public static void ToCSV( DataTable dtDataTable, string strFilePath)
        {
            StreamWriter sw = new StreamWriter(strFilePath, false);
            //headers    
            for (int i = 0; i < dtDataTable.Columns.Count; i++)
            {
                sw.Write(dtDataTable.Columns[i]);
                if (i < dtDataTable.Columns.Count - 1)
                {
                    sw.Write(",");
                }
            }
            sw.Write(sw.NewLine);
            foreach (DataRow dr in dtDataTable.Rows)
            {
                for (int i = 0; i < dtDataTable.Columns.Count; i++)
                {
                    if (!Convert.IsDBNull(dr[i]))
                    {
                        string value = dr[i].ToString();
                        if (value.Contains(','))
                        {
                            value = String.Format("\"{0}\"", value);
                            sw.Write(value);
                        }
                        else
                        {
                            sw.Write(dr[i].ToString());
                        }
                    }
                    if (i < dtDataTable.Columns.Count - 1)
                    {
                        sw.Write(",");
                    }
                }
                sw.Write(sw.NewLine);
            }
            sw.Close();
        }
    }
    public static class B
    {
        public static void Reset(DataTable dtDataTable, string strFilePath)
        {
            dtDataTable = new DataTable();
            ToCSV(dtDataTable, strFilePath);
            //File.Delete(strFilePath);
        }
        public static void ReadCSV(ObservableDictionary<int, Department> department, string filename)
        {
            var st = new StreamReader(filename);
            var line1 = st.ReadLine();//Skip Line
            while (!st.EndOfStream)
            {
                var line = st.ReadLine();
                var values = line.Split(',');
                var dep = new Department(values[1], Convert.ToInt32(values[2]),Convert.ToInt32(values[3]));

                var productIds = values[4].Split(';');
                for (int i = 0; i < productIds.Length-1; i += 2)
                {
                    dep.AddProduct(Convert.ToInt32(productIds[i]), Convert.ToInt32(productIds[i + 1]));
                }
                
                var employeeIds = values[5].Split(';');
                for (int i = 0; i < employeeIds.Length - 1; i++)
                {
                    dep.AddEmployee(Convert.ToInt32(employeeIds[i]));
                }
                department.Add(Convert.ToInt32(values[0]), dep);
            }
        }
        public static void ToCSV(DataTable dtDataTable, string strFilePath)
        {
            StreamWriter sw = new StreamWriter(strFilePath, false);
            //headers    
            for (int i = 0; i < dtDataTable.Columns.Count; i++)
            {
                sw.Write(dtDataTable.Columns[i]);
                if (i < dtDataTable.Columns.Count - 1)
                {
                    sw.Write(",");
                }
            }
            sw.Write(sw.NewLine);


            foreach (DataRow dr in dtDataTable.Rows)
            {
                for (int i = 0; i < dtDataTable.Columns.Count; i++)
                {
                    if (!Convert.IsDBNull(dr[i]))
                    {
                        if(dr[i] is Dictionary<int,int> dic)
                        {
                            foreach(var pair in dic)
                            sw.Write("{0};{1};", pair.Key, pair.Value);
                        }
                        else if (dr[i] is SortedSet<int> set)
                        {
                            foreach (var item in set)
                            sw.Write("{0};", item);
                        }
                        else
                        {
                            string value = dr[i].ToString();
                            if (value.Contains(','))
                            {
                                value = String.Format("\"{0}\"", value);
                                sw.Write(value);
                            }
                            else
                            {
                                sw.Write(dr[i].ToString());
                            }

                        }
                    }
                    if (i < dtDataTable.Columns.Count - 1)
                    {
                        sw.Write(",");
                    }
                }
                sw.Write(sw.NewLine);
            }
            sw.Close();
        }
    }
    public static class C
    {
        public static void ToCSV(DataTable dtDataTable, string strFilePath)
        {
            StreamWriter sw = new StreamWriter(strFilePath, false);
            //headers    
            for (int i = 0; i < dtDataTable.Columns.Count; i++)
            {
                sw.Write(dtDataTable.Columns[i]);
                if (i < dtDataTable.Columns.Count - 1)
                {
                    sw.Write(",");
                }
            }
            sw.Write(sw.NewLine);
            foreach (DataRow dr in dtDataTable.Rows)
            {
                for (int i = 0; i < dtDataTable.Columns.Count; i++)
                {
                    if (!Convert.IsDBNull(dr[i]))
                    {
                        string value = dr[i].ToString();
                        if (value.Contains(','))
                        {
                            value = String.Format("\"{0}\"", value);
                            sw.Write(value);
                        }
                        else
                        {
                            sw.Write(dr[i].ToString());
                        }
                    }
                    if (i < dtDataTable.Columns.Count - 1)
                    {
                        sw.Write(",");
                    }
                }
                sw.Write(sw.NewLine);
            }
            sw.Close();
        }
        public static void ReadCSV(ObservableDictionary<int, Product> products, string filename)
        {
            var st = new StreamReader(filename);
            var line1 = st.ReadLine();//Skip Line
            while (!st.EndOfStream)
            {
                var line = st.ReadLine();
                var values = line.Split(',');
                products.Add(Convert.ToInt32(values[0]), new Product(values[1], Convert.ToInt32(values[2]), Convert.ToDouble(values[3]), Convert.ToDouble(values[4])));
            }
        }
    }
    public static class D
    {
        public static void ToCSV(DataTable dtDataTable, string strFilePath)
        {
            StreamWriter sw = new StreamWriter(strFilePath, false);
            //headers    
            for (int i = 0; i < dtDataTable.Columns.Count; i++)
            {
                sw.Write(dtDataTable.Columns[i]);
                if (i < dtDataTable.Columns.Count - 1)
                {
                    sw.Write(",");
                }
            }
            sw.Write(sw.NewLine);
            foreach (DataRow dr in dtDataTable.Rows)
            {
                for (int i = 0; i < dtDataTable.Columns.Count; i++)
                {
                    if (!Convert.IsDBNull(dr[i]))
                    {
                        string value = dr[i].ToString();
                        if (dr[i] is Product product)
                        {
                                sw.Write("{0};{1};{2};{3}", product.Name, product.DepartmentID, product.SellingPrice, product.BuyingPrice);
                        }
                        else
                        {
                            if (value.Contains(','))
                            {
                                value = String.Format("\"{0}\"", value);
                                sw.Write(value);
                            }
                            else
                            {
                                sw.Write(dr[i].ToString());
                            }
                        }
                    }
                    if (i < dtDataTable.Columns.Count - 1)
                    {
                        sw.Write(",");
                    }
                }
                sw.Write(sw.NewLine);
            }
            sw.Close();
        }
        public static void ReadCSV(ObservableCollection<Order> orders, string filename)
        {
            var st = new StreamReader(filename);
            var line1 = st.ReadLine();//Skip Line
            while (!st.EndOfStream)
            {
                var line = st.ReadLine();
                var values = line.Split(',');

                var productInfo = values[1].Split(';');
                var product = new Product(productInfo[0], Convert.ToInt32(productInfo[1]), Convert.ToDouble(productInfo[2]), Convert.ToDouble(productInfo[3]));
                orders.Add(new Order(Convert.ToInt32(values[0]), product, Convert.ToInt32(values[2]), Convert.ToDateTime(values[3])));
            }
        }
    }
}
